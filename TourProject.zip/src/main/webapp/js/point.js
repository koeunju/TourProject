
function ready() {
	alert('준비중에 있습니다.');
}




function morePoint() {
		$('#pointView').show();
		$('#close').show();
		$('#more').hide();
	
}

function closePoint() {
		$('#pointView').hide();
		$('#close').hide();
		$('#more').show();
	
}