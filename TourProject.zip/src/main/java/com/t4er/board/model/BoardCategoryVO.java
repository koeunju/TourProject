package com.t4er.board.model;

import lombok.Data;

@Data
public class BoardCategoryVO {

    private String cg_num;
    private String cg_name;
}
