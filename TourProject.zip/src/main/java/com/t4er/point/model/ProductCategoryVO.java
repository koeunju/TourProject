package com.t4er.point.model;

import lombok.Data;

@Data
public class ProductCategoryVO {

    private String Cg_num;
    private String Cg_name;
}
