package com.t4er.tour.service;

import com.t4er.tour.model.TourVO;

public interface TourService {

    int insertSaveTour(TourVO tvo);
}
