package com.t4er.olan.service;

public interface SampleService {

    int totalCount();
}
