package com.t4er.olan.mapper;

public interface SampleMapper {

    int totalCount();
}
